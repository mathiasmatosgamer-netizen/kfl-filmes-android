# 📱 Como Compilar e Baixar o APK via GitHub

## ⚡ Passo 1: Criar Repositório GitHub

1. **Acesse GitHub**: https://github.com/new
2. **Crie um novo repositório**:
   - Nome: `kfl-filmes-android`
   - Descrição: "Aplicativo de streaming de filmes e séries"
   - Selecione "Public"
   - Clique em "Create repository"

## 📤 Passo 2: Fazer Upload do Código

### Opção A: Via Linha de Comando (Recomendado)

```bash
cd /home/ubuntu/kfl-filmes-android

# Inicialize o git
git init
git add .
git commit -m "Initial commit: KFL FILMES Android App"

# Adicione o repositório remoto
git remote add origin https://github.com/SEU_USUARIO/kfl-filmes-android.git

# Mude para branch main (se necessário)
git branch -M main

# Faça push do código
git push -u origin main
```

### Opção B: Via Interface GitHub

1. Clique em "uploading an existing file"
2. Arraste todos os arquivos da pasta `kfl-filmes-android`
3. Clique em "Commit changes"

## 🤖 Passo 3: GitHub Actions Compilará Automaticamente

Quando você fazer push do código:

1. GitHub Actions será acionado automaticamente
2. Ele vai compilar o APK (leva 5-10 minutos)
3. O APK será disponibilizado como "Release"

## 📥 Passo 4: Baixar o APK

### Opção 1: Via Releases (Mais Fácil)

1. Acesse seu repositório: `https://github.com/SEU_USUARIO/kfl-filmes-android`
2. Clique em "Releases" (lado direito)
3. Baixe o arquivo `KFL-FILMES-v1.0.0.apk`
4. Abra no seu celular e instale

### Opção 2: Via Artifacts

1. Acesse seu repositório
2. Clique em "Actions"
3. Clique no workflow mais recente
4. Desça até "Artifacts"
5. Baixe `app-debug.apk`

## 📱 Passo 5: Instalar no Celular

1. **Baixe o APK** (como descrito acima)
2. **Abra o arquivo** no seu celular
3. **Toque em "Instalar"**
4. **Pronto!** O app está instalado

## ⚙️ Passo 6: Configurar API TMDB

Após instalar:

1. Obtenha uma chave TMDB em: https://www.themoviedb.org/settings/api
2. Abra o app
3. Vá em Configurações
4. Cole sua chave TMDB
5. Pronto! Agora você pode usar o app

## 🔄 Atualizar o APK

Sempre que você fizer mudanças no código:

```bash
git add .
git commit -m "Descrição da mudança"
git push origin main
```

GitHub Actions compilará automaticamente e criará uma nova Release!

## ❓ Dúvidas

### "Não vejo o workflow rodando"
- Verifique a aba "Actions" no seu repositório
- Se não aparecer, verifique se o arquivo `.github/workflows/build.yml` foi enviado

### "O build falhou"
- Verifique os logs em "Actions"
- Certifique-se de que todos os arquivos foram enviados corretamente
- Verifique se o `build.gradle.kts` está correto

### "Não consigo baixar o APK"
- Espere o build terminar (pode levar 10 minutos)
- Atualize a página do GitHub
- Verifique se o workflow foi bem-sucedido (verde ✅)

## 🎉 Pronto!

Seu app está compilado e pronto para usar no celular!

**Próximos passos:**
1. Instale o APK
2. Configure a chave TMDB
3. Aproveite o app! 🎬

