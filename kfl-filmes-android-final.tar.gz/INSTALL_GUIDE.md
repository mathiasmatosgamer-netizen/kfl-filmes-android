# 📱 Guia Completo de Instalação - KFL FILMES

## ⚡ Opção 1: Instalação Rápida (Recomendado)

### Pré-requisitos
- Android 7.0+ (API 24+)
- 150 MB de espaço livre
- Conexão com internet

### Passos

1. **Baixe o Android Studio** (se não tiver):
   - Acesse: https://developer.android.com/studio
   - Selecione seu SO (Windows, Mac, Linux)
   - Instale seguindo o assistente

2. **Clone/Baixe o Projeto**:
   ```bash
   git clone https://github.com/seu-usuario/kfl-filmes-android.git
   cd kfl-filmes-android
   ```

3. **Abra no Android Studio**:
   - Abra o Android Studio
   - File → Open → Selecione a pasta do projeto
   - Aguarde sincronizar (pode levar 5-10 min na primeira vez)

4. **Configure a API TMDB**:
   - Vá para: `src/main/kotlin/com/kflfilmes/app/data/api/TMDBService.kt`
   - Substitua `YOUR_TMDB_API_KEY` pela sua chave
   - Para obter a chave: https://www.themoviedb.org/settings/api

5. **Compile e Execute**:
   - Conecte seu celular via USB
   - Ative o modo de desenvolvedor (Settings → About → Toque 7x em Build Number)
   - No Android Studio: Run → Run 'app'
   - Selecione seu dispositivo
   - Aguarde a instalação (2-3 minutos)

---

## 🔧 Opção 2: Compilação Manual (Avançado)

```bash
# Instale o Android SDK
sudo apt-get install android-sdk

# Clone o projeto
git clone https://github.com/seu-usuario/kfl-filmes-android.git
cd kfl-filmes-android

# Compile o APK
./gradlew assembleDebug

# O APK estará em: app/build/outputs/apk/debug/app-debug.apk

# Instale no celular
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 Opção 3: Instalação via APK Pré-compilado

1. **Baixe o APK**: (será fornecido)
2. **Transfira para o celular** via USB ou email
3. **Abra o arquivo APK** no celular
4. **Toque em "Instalar"**
5. **Pronto!** O app está instalado

---

## ❌ Solução de Problemas

### "Erro de Sincronização do Gradle"
```bash
# Limpe o cache
./gradlew clean

# Sincronize novamente
./gradlew sync
```

### "Dispositivo não aparece no Android Studio"
1. Verifique se o USB está conectado
2. Ative o modo de desenvolvedor no celular
3. Autorize a conexão USB quando solicitado
4. Execute: `adb devices`

### "Erro de API TMDB"
- Verifique se a chave está correta
- Verifique se tem conexão com internet
- Verifique se a chave está ativa na conta TMDB

### "App fecha ao abrir"
- Verifique os logs: `adb logcat`
- Certifique-se de que a chave TMDB está configurada
- Limpe o cache do app: Settings → Apps → KFL FILMES → Clear Cache

---

## 🎯 Primeiro Uso

1. **Abra o app** no seu celular
2. **Aguarde carregar** (primeira vez pode levar alguns segundos)
3. **Explore os filmes e séries**
4. **Use a busca** para encontrar conteúdo específico
5. **Clique em um filme** para ver detalhes e trailer

---

## 💡 Dicas

- **Modo Offline**: O app cacheia dados localmente
- **Economia de Dados**: Desative imagens de alta qualidade nas configurações
- **Múltiplos Idiomas**: Mude o idioma nas configurações
- **Notificações**: Ative para receber novos lançamentos

---

## 📞 Suporte

Se tiver problemas:
1. Verifique este guia
2. Consulte a documentação: https://developer.android.com
3. Abra uma issue no GitHub

---

**Pronto para usar! 🚀**
