package com.kflfilmes.app.data.models

import com.google.gson.annotations.SerializedName

data class Movie(
    val id: Int,
    val title: String,
    @SerializedName("poster_path")
    val posterPath: String?,
    @SerializedName("backdrop_path")
    val backdropPath: String?,
    val overview: String,
    @SerializedName("release_date")
    val releaseDate: String,
    @SerializedName("vote_average")
    val voteAverage: Double,
    @SerializedName("vote_count")
    val voteCount: Int,
    @SerializedName("genre_ids")
    val genreIds: List<Int>,
    val popularity: Double
)

data class MovieDetails(
    val id: Int,
    val title: String,
    @SerializedName("poster_path")
    val posterPath: String?,
    @SerializedName("backdrop_path")
    val backdropPath: String?,
    val overview: String,
    @SerializedName("release_date")
    val releaseDate: String,
    @SerializedName("vote_average")
    val voteAverage: Double,
    val budget: Long,
    val revenue: Long,
    val runtime: Int,
    val genres: List<Genre>,
    val credits: Credits,
    val videos: Videos,
    val similar: MovieResponse?,
    val recommendations: MovieResponse?
)

data class MovieResponse(
    val results: List<Movie>
)

data class Genre(
    val id: Int,
    val name: String
)

data class Credits(
    val cast: List<Cast>,
    val crew: List<Crew>
)

data class Cast(
    val id: Int,
    val name: String,
    val character: String,
    @SerializedName("profile_path")
    val profilePath: String?
)

data class Crew(
    val id: Int,
    val name: String,
    val job: String,
    val department: String
)

data class Videos(
    val results: List<Video>
)

data class Video(
    val id: String,
    val key: String,
    val name: String,
    val site: String,
    val type: String
)
