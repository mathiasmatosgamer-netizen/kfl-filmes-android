package com.kflfilmes.app.data.repository

import com.kflfilmes.app.data.api.TMDBService
import com.kflfilmes.app.data.models.*

class MediaRepository(private val tmdbService: TMDBService, private val apiKey: String) {

    // Movies
    suspend fun getPopularMovies(page: Int = 1): List<Movie> {
        return try {
            tmdbService.getPopularMovies(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTopRatedMovies(page: Int = 1): List<Movie> {
        return try {
            tmdbService.getTopRatedMovies(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getNowPlayingMovies(page: Int = 1): List<Movie> {
        return try {
            tmdbService.getNowPlayingMovies(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getUpcomingMovies(page: Int = 1): List<Movie> {
        return try {
            tmdbService.getUpcomingMovies(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getMovieDetails(movieId: Int): MovieDetails? {
        return try {
            tmdbService.getMovieDetails(movieId, apiKey)
        } catch (e: Exception) {
            null
        }
    }

    // TV Series
    suspend fun getPopularSeries(page: Int = 1): List<Series> {
        return try {
            tmdbService.getPopularSeries(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getTopRatedSeries(page: Int = 1): List<Series> {
        return try {
            tmdbService.getTopRatedSeries(apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getSeriesDetails(seriesId: Int): SeriesDetails? {
        return try {
            tmdbService.getSeriesDetails(seriesId, apiKey)
        } catch (e: Exception) {
            null
        }
    }

    // Search
    suspend fun searchMovies(query: String, page: Int = 1): List<Movie> {
        return try {
            tmdbService.searchMovies(query, apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun searchSeries(query: String, page: Int = 1): List<Series> {
        return try {
            tmdbService.searchSeries(query, apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Genres
    suspend fun getMovieGenres(): List<Genre> {
        return try {
            tmdbService.getMovieGenres(apiKey).genres
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getSeriesGenres(): List<Genre> {
        return try {
            tmdbService.getSeriesGenres(apiKey).genres
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Discover
    suspend fun discoverMoviesByGenre(genreId: Int, page: Int = 1): List<Movie> {
        return try {
            tmdbService.discoverMoviesByGenre(genreId, apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun discoverSeriesByGenre(genreId: Int, page: Int = 1): List<Series> {
        return try {
            tmdbService.discoverSeriesByGenre(genreId, apiKey, page = page).results
        } catch (e: Exception) {
            emptyList()
        }
    }
}
