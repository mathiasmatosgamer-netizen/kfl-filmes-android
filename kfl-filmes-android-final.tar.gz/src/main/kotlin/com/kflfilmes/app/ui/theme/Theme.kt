package com.kflfilmes.app.ui.theme

import androidx.compose.foundation.isSystemInDarkMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF6B35),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFF8C42),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFF1E1E2E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2A2A3E),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF0F3460),
    onTertiary = Color.White,
    background = Color(0xFF0F0F1E),
    onBackground = Color.White,
    surface = Color(0xFF1A1A2E),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF2A2A3E),
    onSurfaceVariant = Color(0xFFB0B0B0),
    error = Color(0xFFCF6679),
    onError = Color.Black,
    outline = Color(0xFF4A4A5E)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFFF6B35),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFF8C42),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFF1E1E2E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8E8E8),
    onSecondaryContainer = Color.Black,
    tertiary = Color(0xFF0F3460),
    onTertiary = Color.White,
    background = Color(0xFFFAFAFA),
    onBackground = Color.Black,
    surface = Color(0xFFFFFFFF),
    onSurface = Color.Black,
    surfaceVariant = Color(0xFFE8E8E8),
    onSurfaceVariant = Color(0xFF505050),
    error = Color(0xFFB3261E),
    onError = Color.White,
    outline = Color(0xFF79747E)
)

@Composable
fun KFLFilmesTheme(
    darkTheme: Boolean = isSystemInDarkMode(),
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
