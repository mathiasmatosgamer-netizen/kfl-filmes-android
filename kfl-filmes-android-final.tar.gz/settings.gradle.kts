__manus_ec=$?; trap '' PIPE; printf "%d:%s\n" $__manus_ec "$PWD" >&3 2>/dev/null; trap - PIPE
 source /home/ubuntu/.user_env
