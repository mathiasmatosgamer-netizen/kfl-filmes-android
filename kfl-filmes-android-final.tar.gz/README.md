# KFL FILMES - Aplicativo Android

Aplicativo completo de streaming de filmes e séries para Android.

## 📋 Requisitos

- Android Studio (versão 2023.1 ou superior)
- Android SDK 24+
- Java 17+
- Gradle 8.0+

## 🚀 Como Compilar

1. **Abra o Android Studio**
2. **Selecione "Open" e navegue até este diretório**
3. **Aguarde o Gradle sincronizar as dependências**
4. **Clique em "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"**
5. **Aguarde a compilação terminar**

O arquivo APK será gerado em: `app/build/outputs/apk/debug/app-debug.apk`

## 📱 Como Instalar no Celular

1. **Conecte seu celular via USB**
2. **Ative o modo de desenvolvedor no celular**
3. **No Android Studio, clique em "Run" > "Run 'app'"**
4. **Selecione seu dispositivo**
5. **Aguarde a instalação**

## 🎬 Funcionalidades

✅ Filmes populares, bem avaliados e em cartaz
✅ Séries populares e bem avaliadas
✅ Busca em tempo real
✅ Navegação por gêneros
✅ TV Aberta brasileira
✅ Detalhes completos com elenco
✅ Trailers via YouTube
✅ Interface dark mode elegante
✅ Múltiplos idiomas
✅ Cache local para otimizar performance

## 🔑 Configuração da API TMDB

1. Acesse: https://www.themoviedb.org/settings/api
2. Copie sua chave de API
3. Abra `src/main/kotlin/com/kflfilmes/app/data/api/TMDBService.kt`
4. Substitua `YOUR_TMDB_API_KEY` pela sua chave

## 📦 Estrutura do Projeto

```
src/main/
├── kotlin/com/kflfilmes/app/
│   ├── MainActivity.kt
│   ├── data/
│   │   ├── api/TMDBService.kt
│   │   ├── models/
│   │   │   ├── Movie.kt
│   │   │   └── Series.kt
│   │   └── repository/MediaRepository.kt
│   └── ui/
│       ├── screens/HomeScreen.kt
│       ├── theme/Theme.kt
│       └── navigation/Navigation.kt
├── AndroidManifest.xml
└── res/
    └── values/strings.xml
```

## 🧪 Testes

```bash
./gradlew test
```

## 📝 Licença

MIT

## 👨‍💻 Desenvolvido com Kotlin + Jetpack Compose + Material Design 3

Pronto para usar! 🎉
